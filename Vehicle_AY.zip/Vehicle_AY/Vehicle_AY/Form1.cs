﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolBar;

namespace Vehicle_AY
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


			//pass.Controls.Add(checkBox1);
			//checkBox1.Location = new Point(95, 0);
			//checkBox1.BackColor = Color.Transparent;

			//pass.UseSystemPasswordChar = true;

			////Subscribe to Event
			//checkBox1.Checked += new MouseEventHandler(checkBox1_Checked);
			//checkBox1.CheckedChanged += new MouseEventHandler(checkBox1_CheckedChanged);
		}

        private const string ConnectionString = "Data Source=GUNJAN\\SPARAT;Initial Catalog =Vehicle_WB;User ID=sa;Password=Sql12@";
        SqlConnection con = new SqlConnection(ConnectionString);


        static string Encrypt(string value)
        {
            using(MD5CryptoServiceProvider md = new MD5CryptoServiceProvider())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                byte[] data = md.ComputeHash(utf8.GetBytes(value));
                return Convert.ToBase64String(data);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        
        {

            try { 
            con.Open();
           
            SqlCommand cmd = new SqlCommand("First_SP",con);
            
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Type", SqlDbType.NVarChar).Value = "SEL";
            cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = username.Text.ToString();
            cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = pass.Text.ToString();





                   // with using usertype
                 



          // cmd.Parameters.Add("@Role", SqlDbType.NVarChar).Value = comboBox1.Text.ToString();
                //     SqlDataAdapter sda = new SqlDataAdapter(cmd);
                // DataTable dt1 = new DataTable();
                // sda.Fill(dt1);

                // if(dt1 != null)
                //{
                //         if (dt1.Rows.Count > 0)
                //         {
                //             if(comboBox1.Text ==   "Admin")

                //             this.Hide();
                //             Form3 form3 = new Form3();
                //             form3.Show();

                //             MessageBox.Show("login successfully");
                //         }
                //             else if (comboBox1.Text == "OPERATOR")
                //         {
                //             this.Hide();
                //             Form6 form6 = new Form6();
                //             form6.Show();
                //             MessageBox.Show("welcome to driver detail");
                //         }

                //         else if (comboBox1.Text == "SECURITY")
                //         {
                //             this.Hide();
                //             Form5 form5 = new Form5();
                //             form5.Show();
                //             MessageBox.Show("welcome to driver detail");
                //         }



                //         else
                //         {
                //             MessageBox.Show("Check your username ,password and role");
                //         }
                //         //MessageBox.Show("login successfully");



                //     }
                // else
                // {
                //     MessageBox.Show("login failed");
                // }

                // without using usertype


                SqlDataReader dr = cmd.ExecuteReader();
                //if(dr.Read())
                //{
                    if(dr.HasRows)
                    {
                        dr.Read();
                        if (dr[6].ToString()=="ADMIN")
                        {

                            this.Hide();
                            Form2 form2 = new Form2();
                             form2.Show();
						MessageBox.Show("welcome to admin page");

					}
                        else if (dr[6].ToString() == "OPERATOR")
                        {
                            this.Hide();
                            Form8 form8 = new Form8();
                            form8.Show();
                            MessageBox.Show("welcome to operator page ");
                        }
                        else if (dr[6].ToString() == "SECURITY")
                        {
                            this.Hide();
                            Form5 form5 = new Form5(dr[6].ToString());
                            form5.Show();
                           
                            MessageBox.Show("welcome to security page");
						
					}
                    }


                else
                       {
                          MessageBox.Show("Check your username  and password ");
                        }

              //  }

              //  else
                //{
               //    MessageBox.Show("login failed");
                // }


            }





            //SqlDataReader dr = cmd.ExecuteReader();
            //if(dr.Read())








            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }


            






            if (string.IsNullOrEmpty(pass.Text))
            {
                MessageBox.Show("Please enter your passowrd", "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else
            {
                label4.Text = Encrypt(label4.Text);   
            }
          
       
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {
                     }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{
			if (checkBox1.Checked)
			{
				pass.UseSystemPasswordChar = false;


			}
			else
			{
				pass.UseSystemPasswordChar = true;

			}
		}

		private void label5_Click(object sender, EventArgs e)
		{

		}

		private void label8_Click(object sender, EventArgs e)
		{

		}
	}
}

