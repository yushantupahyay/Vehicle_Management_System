﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vehicle_AY
{
    public partial class Formfirst : Form
    {
        public Formfirst()
        {
            InitializeComponent();
        }

        private void Formfirst_Load(object sender, EventArgs e)
        {

        }
        int starpoint = 0; 
        private void timer1_Tick(object sender, EventArgs e)
        {

            timer1.Enabled = true;
            progressBar1.Increment(2);
            if(progressBar1.Value == 100)
            {
                timer1.Enabled = false;
                this.Hide();
                Form1 form1 = new Form1();
                    form1.Show();
            }
            
            //starpoint += 1;
            //pictureBox1 = starpoint;
            //if (pictureBox1.Value == 100)
            //{
            //    pictureBox1.Value = 0;
            //    timer1.Stop();
            //    this.Hide();
            //    Form1 form1 = new Form1;
            //    form1.Show();
            }

		private void progressBar1_Click(object sender, EventArgs e)
		{

		}
	}

        //private void pictureBox2_Click(object sender, EventArgs e)
        //{

        //}
    }

