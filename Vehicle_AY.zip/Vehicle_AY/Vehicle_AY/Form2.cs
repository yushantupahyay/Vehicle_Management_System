﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vehicle_AY
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
			this.Hide();
			Form1 form1 = new Form1();
			form1.Show();
		}
        private void button1_Click(object sender, EventArgs e)
        {

            this.Hide();
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 form8 = new Form8();
            form8.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //this.Hide();
            //Form1 form1 = new Form1();
            //form1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
			//if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
			//{
			//    printDocument1.Print();
			//}



			this.Hide();
			Form5 form5 = new Form5();
			form5.Show();
		}

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            //e.Graphics.DrawString("======DRIVER SUMMARY=====", new Font("century Gothic", 25, FontStyle.Bold), Brushes.Red, new Point(230));
          //  e.Graphics.DrawString("Driver_ID"  + textBox1.Text, new Font("century Gothic", 25, FontStyle.Bold), Brushes.Red, new Point(230));
        }

		private void pictureBox5_Click(object sender, EventArgs e)
		{

		}
	}
}

