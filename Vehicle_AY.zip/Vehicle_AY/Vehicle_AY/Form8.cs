﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Vehicle_AY
{
	public partial class Form8 : Form
	{
		public Form8()
		{
			InitializeComponent();
			GetVehicleList();
		}


		SqlConnection con = new SqlConnection("Data Source=GUNJAN\\SPARAT;Initial Catalog = Vehicle_WB;User ID=sa;Password=Sql12@");

		private void button1_Click(object sender, EventArgs e)
		{

			SqlCommand cmd = new SqlCommand();
			cmd.Connection = con;
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.CommandText = "truck_SP";
			cmd.Parameters.AddWithValue("@ture", textBox1.Text);

			cmd.Parameters.AddWithValue("@gross", textBox3.Text);
			cmd.Parameters.AddWithValue("@entry", dateTimePicker1.Text);
			cmd.Parameters.AddWithValue("@exit", dateTimePicker2.Text);

			con.Open();
			cmd.ExecuteNonQuery();
			clear();
			con.Close();

			MessageBox.Show("Successfully Inserted");
			GetVehicleList();
		}

		    void clear()
		{
			textBox1.Clear();
			textBox3.Clear();
		}



		void GetVehicleList()
		{
			SqlCommand c = new SqlCommand("Listtruck_SP", con);
			SqlDataAdapter sd = new SqlDataAdapter(c);
			DataTable dt = new DataTable();
			sd.Fill(dt);
			dataGridView1.DataSource = dt;
		}

		private void label1_Click(object sender, EventArgs e)
		{

		}

		private void label3_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form2 form2 = new Form2();
			form2.Show();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form1 form1 = new Form1();
			form1.Show();
		}

		private void Form8_Load(object sender, EventArgs e)
		{
			textBox2.Text = Form3.recy;
		}
	}
}
