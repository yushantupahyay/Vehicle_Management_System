﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Vehicle_AY
{
    public partial class Form3 : Form
    {

        public static string username = "";
        public static string role = "";
        public Form3()
        {
            InitializeComponent();
        }


        public static string usernames;
        public static string recy
        {
            get { return usernames; }
            set { usernames = value; }
        }
        SqlConnection con = new SqlConnection("Data Source=GUNJAN\\SPARAT;Initial Catalog=Vehicle_WB;User ID=sa;Password=Sql12@");
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


			recy = Name.Text;
			con.Open();

            SqlCommand cmd = new SqlCommand("First_SP", con);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Type", SqlDbType.NVarChar).Value = "INS";
            cmd.Parameters.Add("@EMP_ID", SqlDbType.NVarChar).Value = ID.Text.ToString();

            cmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = Email.Text.ToString();
            cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = Password.Text.ToString();
            cmd.Parameters.Add("@Role", SqlDbType.NVarChar).Value = comboBox1.Text.ToString();
            cmd.Parameters.Add("@Name", SqlDbType.NVarChar).Value = Name.Text.ToString();
            cmd.Parameters.Add("@mobile", SqlDbType.NVarChar).Value = Mobile.Text.ToString();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt1 = new DataTable();
            sda.Fill(dt1);
            clear();
            

            username = Name.Text;
            role = comboBox1.Text;


			con.Close();
            MessageBox.Show("Save successfully");


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {




            this.Hide();
            Form2 form2 = new Form2();
            form2.Show();

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
		{
		}


		void clear()
		{
			ID.Clear();
			Name.Clear();
			Mobile.Clear();
			Password.Clear();
            Email.Clear();
            comboBox1.Text = string.Empty;


		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Password.UseSystemPasswordChar = false;


            }
            else
            {
                Password.UseSystemPasswordChar = true;
            }
        }

		private void pictureBox2_Click_1(object sender, EventArgs e)
		{

		}
	}
}
