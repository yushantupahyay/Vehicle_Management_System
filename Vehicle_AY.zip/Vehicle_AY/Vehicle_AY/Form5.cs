﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//Data Source = GUNJAN\SPARAT; Initial Catalog = Vehicle_WB; Integrated Security = True
namespace Vehicle_AY
{
    public partial class Form5 : Form
    {
		private DataTable dataTable;
		private const string WatermarkText = "Select a date";
		public Form5()
        {
            InitializeComponent();
            GetDriverList();
			SetWatermark();

			dateTimePicker1.Enter += dateTimePicker1_Enter;
			dateTimePicker1.Leave += dateTimePicker1_Leave;
			dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
;			//dateTimePicker1.Format = DateTimePickerFormat.Custom;
			//dateTimePicker1.CustomFormat = "dd/MM/yyyy";

		}

		private const string ConnectionString = "Data Source=GUNJAN\\SPARAT;Initial Catalog =Vehicle_WB;User ID=sa;Password=Sql12@";
        //SqlConnection con = new SqlConnection(ConnectionString);
        string dr;
        public Form5(string s)
        {
            InitializeComponent();
            dr = s;

            GetDriverList();

        }
        SqlConnection con = new SqlConnection("Data Source=GUNJAN\\SPARAT;Initial Catalog = Vehicle_WB;User ID=sa;Password=Sql12@");


        private void button1_Click(object sender, EventArgs e)
        {
           

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "vehicle_SP";
            cmd.Parameters.AddWithValue("@driver_id", textBox1.Text);
            cmd.Parameters.AddWithValue("@driver_name", textBox2.Text);
            cmd.Parameters.AddWithValue("@License", textBox3.Text);
            cmd.Parameters.AddWithValue("@from_date", dateTimePicker1.Text);
            cmd.Parameters.AddWithValue("@to_date", dateTimePicker2.Text);
            cmd.Parameters.AddWithValue("@weight", textBox6.Text);
            con.Open();
            cmd.ExecuteNonQuery();
			clear();
			con.Close();

            MessageBox.Show("Successfully Inserted");
            GetDriverList();
			label14.Text = $"total record:{dataGridView2.RowCount}";

        }



        void GetDriverList()
        {
            SqlCommand c = new SqlCommand("ListDriver_SP", con);
            SqlDataAdapter sd = new SqlDataAdapter(c);
            DataTable dt = new DataTable();
             sd.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "Dupdate_SP";
            cmd.Parameters.AddWithValue("@driver_id", textBox1.Text);
            cmd.Parameters.AddWithValue("@driver_name", textBox2.Text);
            cmd.Parameters.AddWithValue("@License", textBox3.Text);
            cmd.Parameters.AddWithValue("@from_date", dateTimePicker1.Text);
            cmd.Parameters.AddWithValue("@to_date", dateTimePicker2.Text);
            cmd.Parameters.AddWithValue("@weight", textBox6.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            clear();

			con.Close();


            MessageBox.Show("Successfully updated");
            GetDriverList();

        }

        private void button3_Click(object sender, EventArgs e)
        {

			this.Hide();
			Form2 form2 = new Form2();
			form2.Show();




			//SqlDataReader dr = cmd.ExecuteReader();
			//if (dr.HasRows)

			//             {
			//	   dr.Read();

			//	if (dr[6].ToString() == "SECURITY")
			//             {
			//                 button3.Hide();
			//             }
			//             else
			//             {

			//                 this.Hide();
			//                 Form2 form2 = new Form2();
			//                 form2.Show();
			//             }
			//         }
		}
		//DataTable table = new DataTable();

		private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
            //table.Columns.Add("driver_id", typeof(int));
            //table.Columns.Add("driver_name", typeof(string));
            //table.Columns.Add("license", typeof(string));
            //table.Columns.Add("from_date", typeof(DateTime));
            //table.Columns.Add("to_date", typeof(DateTime));
            //table.Columns.Add("weight", typeof(float));


            //dataGridView1.DataSource = table;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {



			try
			{
				con.Open();
				SqlCommand cmd = new SqlCommand("First_SP", con);
				cmd.CommandType = CommandType.StoredProcedure;
				SqlDataReader dr = cmd.ExecuteReader();
				if (dr.HasRows)
				{

					dr.Read();
					if (dr[6].ToString() == "ADMIN")
					{
						 button3.Visible = true;
						//button3.Show();
						//this.Hide();
						//Form2 form2 = new Form2();
						//form2.Show();

					}
					else if (dr[6].ToString() == "SECURITY")
					{
						button3.Hide();
						//button3.Visible = false;
                      //  button3.Enabled = false;
					}



				}
				// GetDriverList();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				con.Close();
			}
			
		}

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
			if(Form3.username != null)
			{
				label9.Text = Form3.username;
			}
			else if(Form3.role != null)
			{
				label10.Text = Form3.role;
			}

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteD_SP";
            cmd.Parameters.AddWithValue("@driver_id", textBox1.Text);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();





            MessageBox.Show("Successfully Deleted");
            GetDriverList();


        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }
		Bitmap bitmap;
		private void button5_Click(object sender, EventArgs e)
        {
			//Resize DataGridView to full height.
			int height = dataGridView2.Height;
			dataGridView2.Height = dataGridView2.RowCount * dataGridView2.RowTemplate.Height;

			//Create a Bitmap and draw the DataGridView on it.
			bitmap = new Bitmap(this.dataGridView2.Width, this.dataGridView2.Height);
			dataGridView2.DrawToBitmap(bitmap, new Rectangle(0, 0, this.dataGridView2.Width, this.dataGridView2.Height));

			//Resize DataGridView back to original height.
			dataGridView2.Height = height;

			//Show the Print Preview Dialog.
			printPreviewDialog1.Document = printDocument1;
			printPreviewDialog1.PrintPreviewControl.Zoom = 1;
			printPreviewDialog1.ShowDialog();

			//printDocument1.Print();
			//if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
			//         {
			//   if(picturebox1.viusible= true)          printDocument1.Print();
			//         }


			//printPreviewDialog1.Document = printDocument1;
			//printPreviewDialog1.PrintPreviewControl.Zoom = 1;
			//printPreviewDialog1.ShowDialog();
		}

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
			



			e.Graphics.DrawImage(bitmap, 0, 0);



			//Bitmap imagebmp = new Bitmap(dataGridView2.Width, dataGridView2.Height);
			//dataGridView2.DrawToBitmap(imagebmp, new Rectangle(100, 0, dataGridView2.Width, dataGridView2.Height));
			//e.Graphics.DrawImage(imagebmp, 120, 20);




		}

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {


			GetDriverList();

			if (Form3.username != null)
			{
				label9.Text = Form3.username;
			}
			else if (Form3.role != null)
			{
				label10.Text = Form3.role;
			}

			textBox4.Text = Form3.recy;



			try
			{
				con.Open();
				SqlCommand cmd = new SqlCommand("First_SP", con);
				cmd.CommandType = CommandType.StoredProcedure;
				SqlDataReader dr = cmd.ExecuteReader();
				if (dr.HasRows)
				{

					dr.Read();
					if (dr[6].ToString() == "ADMIN")
					{
						button3.Visible = true;
						//button3.Show();
						//this.Hide();
						//Form2 form2 = new Form2();
						//form2.Show();

					}
					else if (dr[6].ToString() == "SECURITY")
					{
						button3.Hide();
						//button3.Visible = false;
						//button3.Enabled = false;
					}



				}
				// GetDriverList();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			finally
			{
				con.Close();
			}



			
			
			//dateTimePicker1.Format = DateTimePickerFormat.Custom;
			//dateTimePicker1.CustomFormat = "dd-MM-yyyy";


		}

		private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }



        void clear()
        {
            textBox1.Clear();
			textBox2.Clear();
			textBox3.Clear();
			textBox6.Clear();
         }

		private void label8_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form1 form1 = new Form1();
			form1.Show();
		}

		private void label10_Click(object sender, EventArgs e)
		{

		}

		private void label9_Click(object sender, EventArgs e)
		{

		}

		private void textBox4_TextChanged(object sender, EventArgs e)
		{
			
		}

		private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
		{
			
							
				if (char.IsDigit(e.KeyChar) || char.IsLetter(e.KeyChar))
				{

				if (textBox3.Text.Length != 10)
				{
					e.Handled = false;

				}
				else if (textBox3.Text.Length == 9)
				{
					e.Handled = true;
					MessageBox.Show("license number  should be  not less than 10 digit");
				}


				else
				{
					e.Handled = true;
					MessageBox.Show("license number  should be 10 digit");
				}
					
				}
				else if (char.IsControl(e.KeyChar))
				{
					
					e.Handled = false;
				
			    }
				else
				{
					e.Handled = true;

				MessageBox.Show("only digit and character areallowed");
			    }
			

		}

		private void textBox3_TextChanged(object sender, EventArgs e)
		{

		}


		private void SetWatermark()
		{
			if(dateTimePicker1.Value == dateTimePicker1.MinDate)
			{
				dateTimePicker1.CustomFormat = " ";
				dateTimePicker1.Format = DateTimePickerFormat.Custom;
				dateTimePicker1.Text = WatermarkText;
			}
		}



		private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
		{
			//dateTimePicker1.Format = DateTimePickerFormat.Custom;
			dateTimePicker1.CustomFormat = "dd/MM/yyyy";


			 if (dateTimePicker1.Value != DateTimePicker.MinimumDateTime)
            {
                dateTimePicker1.CustomFormat = string.Empty;
                dateTimePicker1.Format = DateTimePickerFormat.Short;
            }

			
		}

		private void button6_Click(object sender, EventArgs e)
		{
			//DateTime startDate = dateTimePicker3.Value;
			//DateTime endDate = dateTimePicker4.Value;

			//// Filter data based on the date range
			//var filteredRows = dataTable.AsEnumerable()
			//	.Where(row => row.Field<DateTime>("from_date") >= startDate && row.Field<DateTime>("to_date") <= endDate);

			//// Update DataGridView with the filtered data
			//DataTable filteredDataTable = filteredRows.CopyToDataTable();
			//dataGridView2.DataSource = filteredDataTable;
		}

		private void label12_Click(object sender, EventArgs e)
		{
			//label2.Text = dateTimePicker1.Value.Date.ToString("dd-MM-yyyy");
		}

		private void dateTimePicker1_Enter(object sender, EventArgs e)
		{

			if (dateTimePicker1.Value == DateTimePicker.MinimumDateTime)
			{
				dateTimePicker1.CustomFormat = " ";
				dateTimePicker1.Format = DateTimePickerFormat.Custom;
				dateTimePicker1.Text = string.Empty;
			}
		}

		private void dateTimePicker1_Leave(object sender, EventArgs e)
		{
			SetWatermark();
		}

		private void button6_Click_1(object sender, EventArgs e)
		{
			//SqlCommand cmd = new SqlCommand("selectdate_SP", con);
			//cmd.CommandType = CommandType.StoredProcedure;
			//con.Open();
			////SqlCommand cmd = new SqlCommand();
			////cmd.Connection = con;
			
			////cmd.CommandText = "selectdate_SP";

			//cmd.Parameters.AddWithValue("@date1", dateTimePicker3.Text);
			//cmd.Parameters.AddWithValue("@date2", dateTimePicker4.Text);

			
			//cmd.ExecuteNonQuery();


			

			//con.Close();

			//MessageBox.Show("your result");


			
			
			
			
			//SqlDataAdapter sd = new SqlDataAdapter(cmd);
			//DataTable dt = new DataTable();

			//sd.Fill(dt);
			//cmd.ExecuteNonQuery();
			//dataGridView2.DataSource = dt;

			//con.Close();




		}

		private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
		{
			dateTimePicker2.CustomFormat = "dd/MM/yyyy";


			if (dateTimePicker1.Value != DateTimePicker.MinimumDateTime)
			{
				dateTimePicker2.CustomFormat = string.Empty;
				dateTimePicker2.Format = DateTimePickerFormat.Short;
			}

		}

		private void button7_Click(object sender, EventArgs e)
		{
			this.Hide();
			Form10 f = new Form10();
			f.Show();

		}
	}
    
}
